# Baxtersweb Maps

Baxtersweb Maps displays dynamic route maps from ACF Pro map marker fields.

It is built for WordPress developers and site builders who already manage structured content with Advanced Custom Fields Pro and want a clean way to display route maps without creating separate maps one by one.

## What it does

- Displays interactive OpenStreetMap maps with Leaflet.
- Reads map markers from ACF Pro repeater fields.
- Supports the ACF OpenStreetMap Field location picker.
- Connects ordered map markers with a route line.
- Displays POIs using built-in WordPress icons, theme icon classes, or plain markers.
- Supports per-POI background colours and nearby-marker grouping.
- Supports posts, pages, and custom post types.
- Includes one-click ACF field setup.
- Provides simple style settings for colours, map height, border radius, and marker labels.
- Bundles Leaflet locally with the plugin.

## Requirements

Baxtersweb Maps currently requires:

- WordPress 6.0 or newer
- PHP 7.4 or newer
- Advanced Custom Fields Pro
- ACF OpenStreetMap Field

The ACF OpenStreetMap field should use **Return Format: Raw data** and should allow **one marker per row**.

## Basic usage

1. Install and activate the required plugins.
2. Install and activate Baxtersweb Maps.
3. Go to **Tools → Baxtersweb Maps**.
4. Click **Set up ACF fields for me**.
5. Edit a selected post type and add map markers.
6. Add the shortcode where the map should display.

```text
[bxtr_map]
```

## Template usage

When outputting maps inside templates or loops, pass the current post ID into the shortcode.

PHP template:

```php
echo do_shortcode('[bxtr_map id="' . get_the_ID() . '"]');
```

Advanced Views Layout:

```twig
[bxtr_map id="{{ _layout.object_id }}"]
```

## Layer controls

Show route and POI layers:

```text
[bxtr_map route="yes" poi="yes"]
```

Show only POI markers:

```text
[bxtr_map route="no" poi="yes"]
```

Show only the route layer:

```text
[bxtr_map route="yes" poi="no"]
```

## External services


Road-following routing is optional. After the site administrator supplies an openrouteservice API key, saved route coordinates are sent from the WordPress server to openrouteservice when route points change. Returned geometry is cached in WordPress; visitor page views do not request routes.

- OpenStreetMap tile policy: https://operations.osmfoundation.org/policies/tiles/
- OpenStreetMap privacy: https://osmfoundation.org/wiki/Privacy_Policy
- OpenStreetMap France: https://www.openstreetmap.fr/
- openrouteservice: https://openrouteservice.org/
- openrouteservice terms: https://openrouteservice.org/terms-of-service/
- openrouteservice privacy: https://openrouteservice.org/privacy-policy/

Leaflet, WordPress Dashicons, and the plugin assets are bundled or supplied locally by WordPress. No icon CDN is used.

## Source code

The plugin source code is included in this plugin package. The JavaScript and CSS files in `assets/js` and `assets/css` are human-readable source files and are not generated from a separate build step. No npm, webpack, or other build tooling is required to regenerate the shipped assets.

## License

GPL v2 or later.


## 1.1.6
- Added a bounded 2 km road-snapping retry for rural itinerary points.

## Routing lifecycle

Saved routes remain available when an API key is removed. Adding a valid key later calculates maps that do not yet have saved road geometry. New or changed routes fall back to dashed straight lines whenever routing is unavailable.
